import { topicManifest } from '../data/topicManifest.js';
import { problemTypeRegistry } from './problemTypeRegistry.js';
import { normalizeProblem } from './normalizeProblem.js';
import { validateProblemCollection } from './validateProblem.js';

const discoveredProblemModules = import.meta.env
  ? import.meta.glob('../data/problems/**/*.js')
  : {};

let discoveryCache;
let validationCache;

function readProblemExports(module) {
  const exported = module?.default || module?.problem || module?.problems || null;
  if (!exported) return [];
  return Array.isArray(exported) ? exported : [exported];
}

function normalizeDiscoveredProblem(problem, path, index) {
  return normalizeProblem({
    ...problem,
    metadata: {
      ...(problem.metadata || {}),
      sourcePath: path,
      sourceIndex: index
    }
  });
}

function reportValidationIssues(result) {
  if (result.valid) return;
  if (typeof process !== 'undefined' && process.env?.NODE_ENV === 'production') return;
  if (typeof console !== 'undefined') {
    console.warn('[problem-validation]', result.errors);
  }
}

export async function discoverProblems(options = {}) {
  const modules = options.modules || discoveredProblemModules;
  const topics = options.topics || topicManifest;
  const registry = options.registry || problemTypeRegistry;
  const shouldUseCache = !options.modules && !options.topics && !options.registry;

  if (shouldUseCache && discoveryCache) return discoveryCache;

  const entries = await Promise.all(
    Object.entries(modules).map(async ([path, loader]) => {
      const module = typeof loader === 'function' ? await loader() : loader;
      return readProblemExports(module).map((problem, index) => normalizeDiscoveredProblem(problem, path, index));
    })
  );

  const problems = entries.flat().filter(Boolean);
  const validation = validateProblemCollection(problems, { topics, registry });
  reportValidationIssues(validation);

  if (shouldUseCache) {
    discoveryCache = problems;
    validationCache = validation;
  }

  return problems;
}

export async function getDiscoveredQuestionsForTopic(topicId, options = {}) {
  const problems = await discoverProblems(options);
  return problems.filter((problem) => problem.topicId === topicId);
}

export async function getProblemValidationResult(options = {}) {
  if (!options.modules && !options.topics && !options.registry && validationCache) return validationCache;
  const problems = await discoverProblems(options);
  return validateProblemCollection(problems, {
    topics: options.topics || topicManifest,
    registry: options.registry || problemTypeRegistry
  });
}

export function clearProblemDiscoveryCache() {
  discoveryCache = undefined;
  validationCache = undefined;
}
